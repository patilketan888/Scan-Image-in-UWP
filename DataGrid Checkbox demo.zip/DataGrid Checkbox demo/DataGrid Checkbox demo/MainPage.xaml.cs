﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace DataGrid_Checkbox_demo
{
    /// <summary>
    /// on admin create chekbox check view  and list checkbox should be checked.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        List<FeatureData> fetureList = new List<FeatureData>();

        public MainPage()
        {
            this.InitializeComponent();
            fillGrid();
        }

        private void fillGrid()
        {
            FeatureData fd = new FeatureData(true,false ,true ,false ,true ,1,"Admin");
            FeatureData fds = new FeatureData(true, false, true, false, true, 1, "Technician");
            fetureList.Add(fd);
            fetureList.Add(fds);


            RoleDataGrid.ItemsSource = fetureList;
        }



    }


    public class FeatureData : INotifyPropertyChanged
    {
        public int featureId { get; set; }
        public string featureName { get; set; }

        public bool Create = false;
        public bool Update = false;
        public bool Delete = false;
        public bool List = false;
        public bool View = false;

        //public string index { get; set; }
        public FeatureData(bool Create, bool Update, bool Delete, bool List, bool View, int featureId, string featureName)
        {
            this.featureId = featureId;
            this.featureName = featureName;
            this.Create = Create;
            this.Update = Update;
            this.Delete = Delete;
            this.List = List;
            this.View = View;
            //this.index = index;
        }

        private bool _IsSelected = false;
        public bool IsSelected { get { return _IsSelected; } set { _IsSelected = value; OnChanged("IsSelected"); } }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnChanged(string prop)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }

        #endregion

    }
}
