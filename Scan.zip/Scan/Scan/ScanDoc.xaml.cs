﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading;
using System.Threading.Tasks;
using Windows.Devices.Enumeration;
using Windows.Devices.Scanners;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Scan
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class ScanDoc : Page
    {

        private DeviceWatcherHelper deviceWatcherHelper;
        private ObservableCollection<DeviceInformationDisplay> resultCollection = new ObservableCollection<DeviceInformationDisplay>();




        public ScanDoc()
        {
            
            this.InitializeComponent();
            deviceWatcherHelper = new DeviceWatcherHelper(resultCollection, Dispatcher);
            StartWatcher();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            CmbScannerList.ItemsSource = resultCollection;
        }
        private void StartWatcher()
        {
            resultCollection.Clear();
            DeviceWatcher deviceWatcher;
            deviceWatcher = DeviceInformation.CreateWatcher(DeviceClass.ImageScanner);

            deviceWatcherHelper.StartWatcher(deviceWatcher);
        }
        private async void Btnscan_Click(object sender, RoutedEventArgs e)
        {

            FolderPicker folderPicker = new FolderPicker();
            folderPicker.SuggestedStartLocation = PickerLocationId.DocumentsLibrary;
            folderPicker.FileTypeFilter.Add("*");

            StorageFolder folder = await folderPicker.PickSingleFolderAsync();
            DeviceInformationDisplay selectedScanner = CmbScannerList.SelectedItem as DeviceInformationDisplay;
            string ScannerID = selectedScanner.Id;
            ScanToFolder(ScannerID, folder);


        }
        public async void ScanToFolder(string deviceId, StorageFolder folder)
        {
            try
            {


                ImageScanner myScanner = await ImageScanner.FromIdAsync(deviceId);



                CancellationTokenSource source = new CancellationTokenSource();
                CancellationToken token = source.Token;


                if (myScanner.IsScanSourceSupported(ImageScannerScanSource.Flatbed))
                {

                    myScanner.FlatbedConfiguration.Format = ImageScannerFormat.DeviceIndependentBitmap;

                    var result = await myScanner.ScanFilesToFolderAsync(ImageScannerScanSource.Flatbed, folder);


                }
                else
                {

                }

            }
            catch (TaskCanceledException ex)
            {
                // Utils.OnScenarioException(ex, ModelDataContext);
            }

        }


 





    }


    public class DeviceInformationDisplay : INotifyPropertyChanged
    {
        private DeviceInformation deviceInfo;

        public DeviceInformationDisplay(DeviceInformation deviceInfoIn)
        {
            deviceInfo = deviceInfoIn;
            // UpdateGlyphBitmapImage();
        }

        public DeviceInformationKind Kind
        {
            get
            {
                return deviceInfo.Kind;
            }
        }

        public string Id
        {
            get
            {
                return deviceInfo.Id;
            }
        }

        public string Name
        {
            get
            {
                return deviceInfo.Name;
            }
        }

        public BitmapImage GlyphBitmapImage
        {
            get;
            private set;
        }

        public bool CanPair
        {
            get
            {
                return deviceInfo.Pairing.CanPair;
            }
        }

        public bool IsPaired
        {
            get
            {
                return deviceInfo.Pairing.IsPaired;
            }
        }

        public IReadOnlyDictionary<string, object> Properties
        {
            get
            {
                return deviceInfo.Properties;
            }
        }

        public DeviceInformation DeviceInformation
        {
            get
            {
                return deviceInfo;
            }

            private set
            {
                deviceInfo = value;
            }
        }

        public void Update(DeviceInformationUpdate deviceInfoUpdate)
        {
            deviceInfo.Update(deviceInfoUpdate);

            OnPropertyChanged("Kind");
            OnPropertyChanged("Id");
            OnPropertyChanged("Name");
            OnPropertyChanged("DeviceInformation");
            OnPropertyChanged("CanPair");
            OnPropertyChanged("IsPaired");

            UpdateGlyphBitmapImage();
        }

        private async void UpdateGlyphBitmapImage()
        {
            DeviceThumbnail deviceThumbnail = await deviceInfo.GetGlyphThumbnailAsync();
            BitmapImage glyphBitmapImage = new BitmapImage();
            await glyphBitmapImage.SetSourceAsync(deviceThumbnail);
            GlyphBitmapImage = glyphBitmapImage;
            OnPropertyChanged("GlyphBitmapImage");
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
    }


}
